# mypackage
This Python package consists of a function that returns the top-n items in an array in descending order.

## building this package locally
`python setup.py sdist`

## installing this from GitHub
`pip install git+https://github.com/Example/python-package.git`

## updating this package from GitHub
`pip install --upgrade git+https://github.com/Example/python-package.git`
